chrome.runtime.onMessage.addListener(function(message, sender, response) {
    if (message.type == 'LoggedIn') {
        app.SetData(message.data);
    }
});

let app;
$(function() {
    app = new Vue({
        el: '#vue',
        data: {
            domain: '',
            email: null,
            login: false,
            before: '',
            page: 0,
            view: 'home',
            complaints: [],
            limit: 20,
            is_more: false,
            reported: false,
            liked: false,
            model: {
                title: '',
                complaint: '',
                screenshot: null,
                fileName: 'Choose file',
            },
            message: {
                home: {
                    success: '',
                    error: '',
                },
                login: {
                    error: '',
                },
                report: {
                    success: '',
                    error: '',
                },
                model: {
                    title: '',
                    complaint: '',
                    screenshot: '',
                },
            },
        },
        mounted: async function() {
            let url = await new Promise(t => {
                chrome.tabs.query({
                    active: true,
                }, function(tabs) {
                    t(tabs[0].url);
                });
            });
            this.domain = new URL(url).host;
            this.email = localStorage.getItem('email');
            this.LoadMoreComplaint();
        },
        methods: {
            LoadMoreComplaint: function() {
                ToggleLoading(true);
                let that = this;
                $.ajax({
                    url: `${DOMAIN}/api/complaints`,
                    method: 'GET',
                    data: {
                        domain: that.domain,
                        page: that.page,
                        email: that.email,
                    },
                    success: function(data) {
                        if (that.email && !data.email) localStorage.removeItem('email');
                        that.email = data.email;
                        that.login = data.email ? true : false;
                        that.complaints = that.complaints.concat(data.complaints);
                        that.page = data.page;
                        that.limit = data.limit;
                        that.is_more = data.is_more;
                        that.reported = data.reported;
                        that.liked = data.liked;
                        ToggleLoading(false);
                    },
                    error: function() {
                        that.message.home.error = 'A network error (such as timeout, interrupted connection or unreachable host) has occurred.';
                        ToggleLoading(false);
                    }
                });
            },
            ReportFruad: function() {
                if (this.login) {
                    this.view = 'report';
                } else {
                    this.view = 'login';
                    this.before = 'report';
                }
                this.message.home.success = this.message.home.error = '';
            },
            LikeApp: function() {
                if (this.login) {
                    ToggleLoading(true);
                    let that = this;
                    $.ajax({
                        url: `${DOMAIN}/api/like`,
                        method: 'POST',
                        data: {
                            email: that.email,
                        },
                        success: function(data) {
                            if (data.status == 200) {
                                that.liked = true;
                            } else if (that.email) {
                                that.email = null;
                                localStorage.removeItem('email');
                            }
                            ToggleLoading(false);
                        },
                        error: function() {
                            that.message.home.error = 'A network error (such as timeout, interrupted connection or unreachable host) has occurred.';
                            ToggleLoading(false);
                        }
                    });
                } else {
                    this.view = 'login';
                    this.before = 'home';
                }
                this.message.home.success = this.message.home.error = '';
            },
            GoogleLogin: function() {
                ToggleLoading(true);
                chrome.runtime.sendMessage({
                    type: 'GoogleLogin',
                    data: {
                        domain: this.domain,
                    },
                });
            },
            SetData: function(data) {
                if (data.email) {
                    this.email = data.email;
                    this.login = data.email ? true : false;
                    this.reported = data.reported;
                    this.liked = data.liked;
                    this.view = this.before ? this.before : 'report';
                    if (this.before == 'home') {
                        this.message.home.success = 'You have successfully logged in.';
                    }
                    this.before = '';
                } else {
                    this.message.login.error = data;
                }
                ToggleLoading(false);
            },
            BackHome: function() {
                this.view = 'home';
            },
            ClearError: function(e) {
                let id = e.target.id;
                this.message.model[id] = '';
                if (id == 'screenshot') {
                    this.model.fileName = this.model.screenshot.split("\\").pop();
                    if (!this.model.fileName) this.model.fileName = 'Choose file';
                }
            },
            Report: function() {
                if (this.reported) return;
                if (!this.model.title) {
                    this.message.model.title = 'Please input title.';
                    return;
                }
                if (!this.model.complaint) {
                    this.message.model.complaint = 'Please input your complaint for this site.';
                    return;
                }
                let screenshot = document.getElementById('screenshot').files[0];
                if (screenshot && !screenshot.type.includes('image')) {
                    this.message.model.screenshot = 'Please upload screenshot or image file.';
                    return;
                }

                let formData = new FormData();
                formData.append('email', this.email);
                formData.append('domain', this.domain);
                formData.append('title', this.model.title);
                formData.append('complaint', this.model.complaint);
                formData.append('screenshot', screenshot);

                ToggleLoading(true);
                let that = this;
                $.ajax({
                    url: `${DOMAIN}/api/report-fraud`,
                    method: 'POST',
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function(data) {
                        if (data.status == 200) {
                            that.message.report.success = 'Your complaints have been reported against this site.';
                            that.reported = true;
                        } else if (data.status == 400) {
                            that.message.report.error = data.error;
                        } else {
                            localStorage.removeItem('email');
                        }
                        ToggleLoading(false);
                    },
                    error: function() {
                        that.message.home.error = 'A network error (such as timeout, interrupted connection or unreachable host) has occurred.';
                        ToggleLoading(false);
                    }
                });
            }
        }
    });
});

function ToggleLoading(status) {
    if (status) $('#loading').show();
    else $('#loading').hide();
}