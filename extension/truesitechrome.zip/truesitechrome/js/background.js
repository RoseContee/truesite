chrome.runtime.onMessage.addListener(async function(message, sender, response) {
    if (message.type == 'GoogleLogin') {
        let result = await googleLogin(message.domain);
        chrome.runtime.sendMessage({
            type: 'LoggedIn',
            data: result,
        });
    }
});


async function googleLogin(domain) {
    return await new Promise(t => {
        const token = generateToken(20);
        chrome.identity.launchWebAuthFlow({
            url: get_google_oauth_url(token),
            interactive: true,
        }, function(redirect_url) {
            if (chrome.runtime.lastError) {
                t(chrome.runtime.lastError.message);
                return;
            }
            redirect_url = new URL(redirect_url);
            if (token != redirect_url.searchParams.get('state')) {
                t('Invalid state parameter');
                return;
            }
            const code = redirect_url.searchParams.get('code');
            $.ajax({
                url: 'https://oauth2.googleapis.com/token',
                method: 'POST',
                data: {
                    code: code,
                    client_id: GOOGLE_CLIENT_ID,
                    client_secret: GOOGLE_CLIENT_SECRET,
                    redirect_uri: REDIRECT_URL,
                    grant_type: 'authorization_code',
                },
                success(data) {
                    $.ajax({
                        url: 'https://oauth2.googleapis.com/tokeninfo',
                        method: 'GET',
                        data: {
                            id_token: data.id_token,
                        },
                        success(data) {
                            $.ajax({
                                url: `${DOMAIN}/api/auth-google`,
                                method: 'POST',
                                data: {
                                    email: data.email,
                                    name: data.name,
                                    avatar: data.picture,
                                    google_id: data.sub,
                                    domain: domain,
                                },
                                success(data) {
                                    if (data.status == 200) {
                                        localStorage.setItem('email', data.email);
                                        t({
                                            email: data.email,
                                            reported: data.reported,
                                            liked: data.liked,
                                        });
                                    } else {
                                        t(data.error);
                                    }
                                },
                                error() {
                                    t('A network error (such as timeout, interrupted connection or unreachable host) has occurred.');
                                }
                            });
                        },
                        error() {
                            t('A network error (such as timeout, interrupted connection or unreachable host) has occurred.');
                        }
                    });
                },
                error() {
                    t('A network error (such as timeout, interrupted connection or unreachable host) has occurred.');
                }
            })
        });
    });
}

function generateToken(length) {
    var token           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++ ) {
        token += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
   return token;
}

function get_google_oauth_url(state) {
    return `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(GOOGLE_CLIENT_ID)}
&response_type=code
&redirect_uri=${encodeURIComponent(REDIRECT_URL)}
&state=${state}
&scope=${encodeURIComponent('profile email')}
&prompt=consent
&nonce=${generateToken(21)}
&access_type=offline`;
}