//const DOMAIN = 'https://truesites.co.in';
const DOMAIN = 'http://localhost:10002';

const REDIRECT_URL = 'https://ghjhdjkaadncenfchjikiboaakoeaanm.chromiumapp.org/';

//const GOOGLE_CLIENT_ID = '90280042510-9utm64mgjb5bdvtfqp2ikd57ohntrd8o.apps.googleusercontent.com';
//const GOOGLE_CLIENT_SECRET = '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';
const GOOGLE_CLIENT_ID = '388169861441-cpafmpgfo2n3m06v6b9efbffh4ul4qb2.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = 'bzLsymkKCt0X60_5mFaylGHn';